apbs-pdb2pqr
============

This is a temporary home for the [APBS and PDB2PQR software](http://www.poissonboltzmann.org) as we consider migrating away from [SourceForge](https://sourceforge.net/projects/apbs/).  Our plans for GitHub migration are in flux so please do not count on this repository being available in the future.

Please see the [user guide](doc/userguide.html) for the documentation index and the [COPYING file](COPYING) for license information.

Please see [programmer's guide](doc/programmerguide.html) for information on working with the PDB2PQR code. 

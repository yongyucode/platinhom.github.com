#include <iostream>
#include <fstream>
#include "MarchingCubes.h"

#define DEBUG

int main(int argc, char* argv[])
{
  MarchingCubes mc;
  mc.read_bounding_box("bounding_box.txt");

#ifdef DEBUG
  std::cout<<"Bounding Box:"<<std::endl;
  std::cout<<mc._boun_box[0][0]<<" "
	   <<mc._boun_box[0][1]<<" "
	   <<mc._boun_box[0][2]<<std::endl;
  std::cout<<mc._boun_box[1][0]<<" "
	   <<mc._boun_box[1][1]<<" "
	   <<mc._boun_box[1][2]<<std::endl;
  std::cout<<"Grid Size:"<<std::endl;
  std::cout<<mc._x_size<<" "
	   <<mc._y_size<<" "
	   <<mc._z_size<<std::endl;
#endif

  mc.read_grid_info("grid_info.txt");

#ifdef DEBUG
  std::cout<<"The First Grid Info: "
	   <<mc._grid_info[0][0]<<" "
	   <<mc._grid_info[0][1]<<" "
	   <<mc._grid_info[0][2]<<" "
	   <<mc._grid_info[0][3]<<std::endl;
  std::cout<<"The Last Grid Info: "
	   <<mc._grid_info[mc._grid_info.size()-1][0]<<" "
	   <<mc._grid_info[mc._grid_info.size()-1][1]<<" "
	   <<mc._grid_info[mc._grid_info.size()-1][2]<<" "
	   <<mc._grid_info[mc._grid_info.size()-1][3]<<std::endl;
#endif

  mc.read_intersection_info("intersection_info.txt");
  
#ifdef DEBUG
  std::cout<<"The First Intersection Info: "<<std::endl;
  std::cout<<mc._inte_dual[0][0]<<" "
	   <<mc._inte_dual[0][1]<<" "
	   <<mc._inte_dual[0][2]<<" "<<std::endl;
  std::cout<<mc._inte_dual[0][3]<<" "
	   <<mc._inte_dual[0][4]<<" "
	   <<mc._inte_dual[0][5]<<" "<<std::endl;
  std::cout<<mc._inte_verts[0][0]<<" "
	   <<mc._inte_verts[0][1]<<" "
	   <<mc._inte_verts[0][2]<<" "<<std::endl;
  std::cout<<mc._inte_normal[0][0]<<" "
	   <<mc._inte_normal[0][1]<<" "
	   <<mc._inte_normal[0][2]<<" "<<std::endl;
  std::cout<<"The Last Intersection Info: "<<std::endl;
  std::cout<<mc._inte_dual[mc._inte_dual.size()-1][0]<<" "
	   <<mc._inte_dual[mc._inte_dual.size()-1][1]<<" "
	   <<mc._inte_dual[mc._inte_dual.size()-1][2]<<" "<<std::endl;
  std::cout<<mc._inte_dual[mc._inte_dual.size()-1][3]<<" "
	   <<mc._inte_dual[mc._inte_dual.size()-1][4]<<" "
	   <<mc._inte_dual[mc._inte_dual.size()-1][5]<<" "<<std::endl;
  std::cout<<mc._inte_verts[mc._inte_verts.size()-1][0]<<" "
	   <<mc._inte_verts[mc._inte_verts.size()-1][1]<<" "
	   <<mc._inte_verts[mc._inte_verts.size()-1][2]<<" "<<std::endl;
  std::cout<<mc._inte_normal[mc._inte_normal.size()-1][0]<<" "
	   <<mc._inte_normal[mc._inte_normal.size()-1][1]<<" "
	   <<mc._inte_normal[mc._inte_normal.size()-1][2]<<" "<<std::endl;
#endif

  mc.save_grid_info();

#ifdef DEBUG
  std::cout<<"The first _data element: "<<mc._data[0]<<std::endl;
  std::cout<<"The last _data element: "<<mc._data[mc._data.size()-1]<<std::endl;
#endif

  mc.initialize_verts();
  //std::cout<<"test:: "<<mc._inte_verts[16][0]<<" "<<mc._inte_verts[16][1]<<" "<<mc._inte_verts[16][2]<<" "<<std::endl;
  //std::cout<<"test:: "<<mc._inte_normal[16][0]<<" "<<mc._inte_normal[16][1]<<" "<<mc._inte_normal[16][2]<<" "<<std::endl;
  mc.save_intersection_info();
  
  //std::cout<<mc._inte_dual.size()<<std::endl;
  //std::cout<<mc._inte_verts.size()<<std::endl;
  //std::cout<<mc._inte_normal.size()<<std::endl;
  /*
#ifdef DEBUG
  std::cout<<"The first xyz indices: "<<std::endl;
  std::cout<<mc._x_verts[0]<<" "
	   <<mc._y_verts[0]<<" "
	   <<mc._z_verts[0]<<std::endl;
  std::cout<<"The last xyz indices: "<<std::endl;
  std::cout<<mc._x_verts[mc._x_verts.size()-1]<<" "
	   <<mc._y_verts[mc._y_verts.size()-1]<<" "
	   <<mc._z_verts[mc._z_verts.size()-1]<<std::endl;
#endif
  */
  /*
  for(int i=0; i<mc._x_verts.size(); i++)
    {
      std::cout<<i<<"-th xyz indices: "<<std::endl;
      std::cout<<mc._x_verts[i]<<" "
	       <<mc._y_verts[i]<<" "
	       <<mc._z_verts[i]<<std::endl;
    }
  */
  mc.run();
  /*
  for(int i=0; i<mc._triangles.size(); i++)
    std::cout<<mc._triangles[i].v1<<" "
	     <<mc._triangles[i].v2<<" "
	     <<mc._triangles[i].v3<<std::endl;
  */
  mc.write_OBJ_file();
  
  return 1;
}

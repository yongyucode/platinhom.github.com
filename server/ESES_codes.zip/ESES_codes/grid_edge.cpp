#include "grid_edge.h"

grid_edge::grid_edge(grid_pointIter p1, grid_pointIter p2){
	point1 = p1;
	point2 = p2;
}

grid_edge::~grid_edge(){

}